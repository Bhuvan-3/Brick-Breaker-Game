/**
 * 
 */
/**
 * 
 */
module Game {
	requires java.desktop;
}